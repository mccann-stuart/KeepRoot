KeepRoot Chrome extension 1.0.0

1. Unzip this bundle.
2. Open chrome://extensions in Chrome.
3. Enable Developer mode.
4. Choose Load unpacked and select the unzipped folder.
5. Open the KeepRoot extension settings and enter your Worker URL and API key.
