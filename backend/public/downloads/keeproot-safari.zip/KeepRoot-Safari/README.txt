KeepRoot Safari extension 1.0.0

1. Open KeepRoot.xcodeproj in Xcode.
2. Select your Apple development team for the app and extension targets.
3. Build and run the macOS or iOS app.
4. Enable KeepRoot in Safari Extensions settings.
5. Open the KeepRoot extension settings and enter your Worker URL and API key.

Apple signing is account-specific, so this bundle contains the clean Xcode project rather than an unsigned app.
